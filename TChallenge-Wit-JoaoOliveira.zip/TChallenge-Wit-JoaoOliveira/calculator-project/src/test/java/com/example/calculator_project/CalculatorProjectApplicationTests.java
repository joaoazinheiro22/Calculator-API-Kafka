package com.example.calculator_project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CalculatorProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
